module.exports = {
    ...require("@layerzerolabs/prettier-config-next"),
};
