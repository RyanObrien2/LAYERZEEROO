import { expect } from 'chai'

describe('Hardhat UnitTest Demo', function () {
    it('should pass', async function () {
        expect(true).equal(true)
    })
})
